"""Train or evaluate the confirmed attention SAC + MAPPO hierarchy."""
from __future__ import annotations

import argparse
from datetime import datetime
import json
import gzip
from pathlib import Path
import sys
from time import monotonic

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

import torch
import yaml

from jv_uav import load_config
from jv_uav.rl.trainer import JointTrainer
from jv_uav.rl.curves import TrainingCurves
from jv_uav.rl.provenance import record_run


def format_progress(rows, elapsed, *, by_update=False, partial=False):
    """Summarize the frames since the previous console line."""
    last = rows[-1]
    count = len(rows)
    reward = sum(row["upper_reward"] for row in rows) / count
    backlog = sum(row["system_max_backlog"] for row in rows) / count
    deaths = sum(len(row["dead_ids"]) for row in rows)
    if by_update:
        serving = sum(row["serving_count"] for row in rows) / count
        label = "partial rollout" if partial else f"update {last['mappo_updates']:05d}"
        return (
            f"[{label}] rollout_T={count} | frames={last['upper_steps']:07d} | "
            f"train_serving_mean={serving:.2f} | avg_reward={reward:.2f} | "
            f"avg_max_backlog={backlog:.2f} | dead={deaths} | SAC={last['sac_updates']:07d} | "
            f"pi_loss={last.get('mappo_actor_loss', 0):.4f} | "
            f"vf_loss={last.get('mappo_value_loss', 0):.4f} | phase={last['phase']} | elapsed={elapsed / 60:.1f}m"
        )
    return (
        f"frame {last['upper_steps']:07d} | ep {last['episodes']:05d} | "
        f"low_steps {last['low_steps']:08d} | avg{count}_reward {reward:9.2f} | "
        f"avg{count}_max_backlog {backlog:9.2f} | dead {deaths:3d} | "
        f"SAC {last['sac_updates']:07d} | MAPPO {last['mappo_updates']:05d} | "
        f"{last['phase']:5s} | elapsed {elapsed / 60:7.1f}m"
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--env-config", type=Path, default=ROOT / "configs/default.yaml")
    parser.add_argument("--train-config", type=Path, default=ROOT / "configs/training_joint_responsibility_v4.yaml")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--run-note", default="", help="Short experiment description saved with source and effective configuration.")
    parser.add_argument("--device", default="auto", choices=["auto", "cpu", "cuda"])
    parser.add_argument("--upper-steps", type=int, help="Additional upper environment steps in this invocation.")
    parser.add_argument("--log-every", type=int, help="Use frame-based console summaries every N upper frames, overriding the configured mode.")
    parser.add_argument("--plot-every", type=int, help="Overwrite training_curves.png every N upper frames (default: config or 100; 0 disables).")
    parser.add_argument("--resume", type=Path, help="Resume this project's trusted checkpoint, including replay and pending transitions.")
    parser.add_argument("--upper-pretrained", type=Path, help="Import a matching Paper1 notebook actor into a fresh joint run; critic and optimizers start fresh.")
    parser.add_argument("--eval-only", action="store_true")
    parser.add_argument("--smoke", action="store_true", help="Small networks, six upper steps with constant SAC updates; not convergence training.")
    parser.add_argument("--threads", type=int, default=1, help="PyTorch CPU threads; one is efficient for the small smoke networks.")
    args = parser.parse_args()
    if args.log_every is not None and args.log_every <= 0:
        parser.error("log-every must be positive")
    if args.plot_every is not None and args.plot_every < 0:
        parser.error("plot-every cannot be negative")
    if args.threads <= 0 or (args.upper_steps is not None and args.upper_steps <= 0):
        parser.error("threads and upper-steps must be positive")
    if args.upper_pretrained and args.resume:
        parser.error("upper-pretrained starts a new run and cannot be combined with resume")
    if args.smoke and args.resume:
        parser.error("--smoke cannot override a resumed checkpoint")
    if args.eval_only and not args.resume:
        parser.error("--eval-only requires --resume")
    torch.set_num_threads(args.threads)
    device = "cuda" if args.device == "auto" and torch.cuda.is_available() else ("cpu" if args.device == "auto" else args.device)
    if device == "cuda" and not torch.cuda.is_available():
        parser.error("CUDA requested but unavailable")
    output = args.output or ROOT / "runs" / datetime.now().strftime("joint_%Y%m%d_%H%M%S")
    output.mkdir(parents=True, exist_ok=True)
    if not args.resume and ((output / "train.jsonl").exists() or (output / "checkpoint.pt").exists()):
        parser.error("output already contains training data; use --resume or a new output directory")
    if args.resume:
        trainer = JointTrainer.load(args.resume, device)
    else:
        env_cfg = load_config(args.env_config)
        cfg = yaml.safe_load(args.train_config.read_text(encoding="utf-8"))
        reward_overrides = cfg.get("upper_reward_overrides", {})
        if not isinstance(reward_overrides, dict) or any(not key.startswith("upper_") for key in reward_overrides):
            parser.error("upper_reward_overrides must be a mapping of upper reward keys")
        env_cfg["reward"].update(reward_overrides)
        if cfg.get("require_upper_pretrained", False) and not args.upper_pretrained:
            parser.error("This transfer config requires --upper-pretrained PATH for a fresh run")
        if cfg.get("transfer_fleet") is not None and int(env_cfg["uavs"]["count"]) != cfg["transfer_fleet"]:
            parser.error("Environment UAV count does not match transfer_fleet")
        if args.smoke:
            env_cfg["time"]["episode_upper_frames"] = 3
            cfg.update(total_upper_steps=6, upper_rollout_steps=2, checkpoint_every_mappo=1, evaluate_every_mappo=0, evaluate_every_frames=2, full_evaluate_every_frames=4, eval_render_every_frames=0, checkpoint_every_frames=2, evaluation_seeds=[1001])
            if cfg.get("update_schedule", {}).get("mode") == "staged":
                cfg["update_schedule"]["switch_after_sac_updates"] = 2
            cfg["sac"].update(hidden=32, heads=2, layers=1, batch_size=8, replay_capacity=256, random_steps=0, learning_starts=0)
            cfg["mappo"].update(hidden=32, epochs=2, minibatch_frames=2)
        transfer_state = None
        if args.upper_pretrained:
            from jv_uav.rl.transfer import read_paper1_actor
            try:
                target_mode = cfg["mappo"].get("observation_mode", "arrival_soc")
                transfer_state, metadata = read_paper1_actor(args.upper_pretrained, int(env_cfg["uavs"]["count"]), target_mode,
                    include_own_return_soc=cfg["mappo"].get("include_own_return_soc", False))
            except (ValueError, RuntimeError, OSError) as error:
                parser.error(str(error))
            expected_hidden = cfg["mappo"].get("transfer_actor_hidden")
            if expected_hidden is not None and metadata["hidden"] != expected_hidden:
                parser.error(f"Source actor hidden width {metadata['hidden']} does not match transfer config {expected_hidden}")
            cfg["mappo"].update(observation_mode=target_mode, actor_architecture="paper1_notebook",
                                transfer_actor_hidden=metadata["hidden"])
            cfg["upper_transfer"] = metadata
        trainer = JointTrainer(env_cfg, cfg, device)
        if transfer_state is not None:
            trainer.mappo.actor.load_state_dict(transfer_state, strict=True)
            print("Imported Paper1 upper actor; fresh critic/lower policy; joint fine-tuning. SHA256=" + metadata["sha256"], flush=True)
    cfg = trainer.cfg
    log_every = args.log_every if args.log_every is not None else cfg.get("log_every_frames", 50)
    if isinstance(log_every, bool) or not isinstance(log_every, int) or log_every <= 0:
        parser.error("log_every_frames must be a positive integer")
    cfg["log_every_frames"] = log_every
    if args.log_every is not None:
        cfg["console_log_mode"] = "frames"
    by_update = cfg.get("console_log_mode", "frames") == "mappo_update"
    disk_log_every = cfg.get("train_log_every_frames", 10)
    if isinstance(disk_log_every, bool) or not isinstance(disk_log_every, int) or disk_log_every <= 0:
        parser.error("train_log_every_frames must be a positive integer")
    cfg["train_log_every_frames"] = disk_log_every
    plot_every = args.plot_every if args.plot_every is not None else cfg.get("plot_every_frames", 100)
    if isinstance(plot_every, bool) or not isinstance(plot_every, int) or plot_every < 0:
        parser.error("plot_every_frames must be a non-negative integer")
    cfg["plot_every_frames"] = plot_every
    if cfg["checkpoint_every_mappo"] < 0 or cfg["evaluate_every_mappo"] < 0:
        parser.error("checkpoint/evaluation intervals cannot be negative")
    (output / "resolved_config.json").write_text(json.dumps({"environment": trainer.env_cfg, "training": cfg, "device": device}, indent=2), encoding="utf-8")
    record_run(ROOT, output, trainer, args)

    for key in ("evaluate_every_frames", "full_evaluate_every_frames", "eval_render_every_frames", "checkpoint_every_frames"):
        if type(cfg.get(key, 0)) is not int or cfg.get(key, 0) < 0:
            parser.error(f"{key} must be a nonnegative integer")

    def evaluate(label, full=True, render=True):
        summaries = []
        seeds = cfg["evaluation_seeds"] if full else cfg["evaluation_seeds"][:1]
        for seed in seeds:
            # Frequent checks store scalar diagnostics; full checks preserve trajectories.
            summaries.append(trainer.evaluate(seed, output / label / f"seed_{seed}" if full else None, render=render))
        with (output / "eval.jsonl").open("a", encoding="utf-8") as stream:
            for summary in summaries:
                stream.write(json.dumps(dict(upper_steps=trainer.upper_steps,
                    sac_updates=trainer.sac_updates, mappo_updates=trainer.mappo_updates,
                    phase=trainer.training_phase(), full_evaluation=full, **summary), allow_nan=False) + "\n")
            stream.flush()
        (output / "latest_eval.json").write_text(json.dumps(summaries, indent=2), encoding="utf-8")
        from jv_uav.rl.eval_curves import save_evaluation_curves
        save_evaluation_curves(output)
        for summary in summaries:
            print(
                f"  eval update {trainer.mappo_updates:05d} | seed {summary['seed']} | "
                f"return {summary['upper_return']:10.2f} | "
                f"avg_max_backlog {summary['mean_max_backlog']:9.2f} | "
                f"frames {summary['frames']:4d}/{summary['configured_frames']} | "
                f"low_steps {summary['low_steps']:4d} | lower_return {summary['lower_return']:.1f} | "
                f"coverage {summary['sensor_coverage_fraction']:.1%} | dead {len(summary['dead_ids']):2d} | "
                f"charge requests/assigned {summary['charge_requests']}/{summary['charging_assignments']} | "
                f"stop {summary['termination_reason']}",
                flush=True,
            )

    if args.eval_only:
        evaluate(f"eval_{trainer.upper_steps:08d}")
        return
    steps = args.upper_steps or cfg["total_upper_steps"]
    console_interval = "every MAPPO update" if by_update else f"every {log_every} frames"
    print(f"Joint SAC + MAPPO | device {device} | additional frames {steps} | log {console_interval}", flush=True)
    print(f"Output: {output.resolve()}", flush=True)
    started = monotonic()
    console_rows = []
    curves = TrainingCurves(output, resume=args.resume, upper_steps=trainer.upper_steps) if plot_every else None
    try:
        with (output / "train.jsonl").open("a", encoding="utf-8") as log, gzip.open(
                output / 'charging_frames.jsonl.gz', 'at', encoding='utf-8', compresslevel=5) as charge_log:
            for step_index in range(steps):
                row = trainer.step()
                credits = row.pop("upper_credit_trace", None)
                if credits:
                    with gzip.open(output / "upper_credit.jsonl.gz", "at", encoding="utf-8", compresslevel=5) as credit_log:
                        for credit in credits:
                            credit_log.write(json.dumps(dict(mappo_update=trainer.mappo_updates, **credit),
                                                        allow_nan=False, separators=(',', ':')) + "\n")
                charge_log.write(json.dumps(dict(upper_steps=row['upper_steps'],
                    episode=trainer.episodes if trainer.episode_over else trainer.episodes + 1,
                    request_probabilities=row["request_probabilities"],
                    upper_observation_mode=row["upper_observation_mode"],
                    upper_input_soc=row["upper_input_soc"], upper_input_return_soc=row["upper_input_return_soc"],
                    frame_in_episode=trainer.env.scene.upper_step,
                    battery_start=row["battery_start"], battery_end=row["battery_end"],
                    assigned_status=row["assigned_status"], lower_reward=row["lower_reward"],
                    lower_reward_terms=row["lower_reward_terms"], phase=row["phase"],
                    failure_records=row["failure_records"], failure_tail=row["failure_tail"],
                    **row['charging_diagnostics']), separators=(',', ':')) + '\n')
                charge_log.flush()  # Persist every completed frame, independently of console output.
                if (row['upper_steps'] % disk_log_every == 0 or row['terminated']
                        or row['truncated'] or row['mappo_updated'] or step_index == steps - 1):
                    serialized = json.dumps(row, allow_nan=False, separators=(',', ':'))
                    log.write(serialized + "\n")
                    log.flush()  # Preserve completed records on process termination.
                    live_tmp = output / 'live_status.tmp.json'
                    live_tmp.write_text(serialized, encoding='utf-8')
                    live_tmp.replace(output / 'live_status.json')
                if row['episode_metrics'] is not None:
                    episode_dir = output / 'episodes'
                    episode_dir.mkdir(exist_ok=True)
                    path = episode_dir / f"episode_{row['episodes']:06d}.json.gz"
                    temporary = path.with_suffix('.tmp')
                    summary = dict(episode=row['episodes'], upper_steps=row['upper_steps'],
                                   upper_return=row['episode_return'], termination_reason=row['termination_reason'],
                                   **row['episode_metrics'])
                    if cfg.get("compact_episode_logs", False):
                        with gzip.open(output / "episodes.jsonl.gz", "at", encoding="utf-8", compresslevel=5) as stream:
                            stream.write(json.dumps(summary, allow_nan=False, separators=(',', ':')) + "\n")
                    else:
                        with gzip.open(temporary, 'wt', encoding='utf-8') as stream:
                            json.dump(summary, stream, allow_nan=False)
                        temporary.replace(path)
                if curves is not None:
                    curves.add(row)
                    if (step_index + 1) % plot_every == 0:
                        curves.save()
                console_rows.append(row)
                report = row["mappo_updated"] if by_update else len(console_rows) >= log_every
                if report:
                    print(format_progress(console_rows, monotonic() - started, by_update=by_update), flush=True)
                    console_rows.clear()
                frame = trainer.upper_steps
                checkpoint_frames = cfg.get("checkpoint_every_frames", 0)
                checkpoint_updates = cfg["checkpoint_every_mappo"]
                if ((checkpoint_frames and frame % checkpoint_frames == 0) or
                        (row["mappo_updated"] and checkpoint_updates and trainer.mappo_updates % checkpoint_updates == 0)):
                    trainer.save(output / "checkpoint.pt")
                quick = cfg.get("evaluate_every_frames", 0)
                full_interval = cfg.get("full_evaluate_every_frames", 0)
                full_due = bool(full_interval and frame % full_interval == 0)
                update_interval = cfg["evaluate_every_mappo"]
                update_due = bool(row["mappo_updated"] and update_interval and trainer.mappo_updates % update_interval == 0)
                if step_index < steps - 1 and (full_due or update_due or (quick and frame % quick == 0)):
                    render_interval = cfg.get("eval_render_every_frames", 0)
                    render_due = bool(render_interval and frame % render_interval == 0)
                    evaluate(f"eval_{frame:08d}", full=full_due or update_due, render=render_due)
    except KeyboardInterrupt:
        # A physical frame may be incomplete. Keep the previous safe checkpoint
        # rather than saving inconsistent policy/rollout state mid-step.
        print("Interrupted. Resume the last completed checkpoint; the active frame was not saved.", flush=True)
        if curves is not None:
            curves.save()
        return
    if console_rows:
        print(format_progress(console_rows, monotonic() - started, by_update=by_update, partial=by_update), flush=True)
    trainer.save(output / "checkpoint.pt")
    if curves is not None:
        curves.save()
    evaluate(f"eval_{trainer.upper_steps:08d}")
    print(f"Saved checkpoint: {(output / 'checkpoint.pt').resolve()}", flush=True)


if __name__ == "__main__":
    main()
