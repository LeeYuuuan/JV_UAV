from __future__ import annotations

from typing import Any, Mapping

import numpy as np

from .config import section
from .low_runner import LowFrameRunner
from .metrics import EpisodeMetrics
from .models import ChargingScheduler, EnergyModel
from .scene import Scene
from .types import (
    EpisodeTrace,
    FramePlan,
    FrameRecord,
    UAVFrameRecord,
    UAVStatus,
)


class UpperReward:
    """Minimal replaceable upper reward; evaluation metrics remain independent."""

    def __init__(self, cfg: Mapping[str, Any]) -> None:
        reward = section(cfg, "reward")
        self.mode = reward.get("upper_reward_mode", "serving_backlog")
        if self.mode not in {"serving_backlog", "lower_data_mean", "paper1_serving_backlog"}:
            raise ValueError("unknown upper_reward_mode")
        self.divisor = float(reward.get("upper_reward_divisor", 1.0))
        if not np.isfinite(self.divisor) or self.divisor <= 0:
            raise ValueError("upper_reward_divisor must be positive and finite")
        self.serving_weight = float(reward["upper_serving_weight"])
        self.backlog_weight = float(reward["upper_frame_max_backlog_weight"])
        self.dead_weight = float(reward["upper_dead_weight"])
        self.lower_return_failure_weight = float(reward.get("upper_lower_return_failure_weight", 0.0))
        if not np.isfinite(self.lower_return_failure_weight) or self.lower_return_failure_weight < 0:
            raise ValueError("upper_lower_return_failure_weight must be finite and nonnegative")
        self.charging_weight = float(reward.get("upper_charging_weight", 0.0))
        self.waiting_weight = float(reward.get("upper_waiting_weight", 0.0))
        self.backlog_scale = float(reward.get("upper_backlog_scale_packets", 1.0))
        if not np.isfinite(self.backlog_scale) or self.backlog_scale <= 0:
            raise ValueError("upper_backlog_scale_packets must be positive and finite")
        self.backlog_cap = reward.get("upper_backlog_cap")
        if self.backlog_cap is not None:
            self.backlog_cap = float(self.backlog_cap)
            if not np.isfinite(self.backlog_cap) or self.backlog_cap < 0:
                raise ValueError("upper_backlog_cap must be finite and nonnegative")
        self.backlog_mode = reward.get("upper_backlog_mode", "linear")
        self.episode_failure_weight = float(reward.get("upper_episode_failure_weight", 0.0))
        if self.backlog_mode not in {"linear", "bounded"}:
            raise ValueError("upper_backlog_mode must be linear or bounded")
        self.backlog_reference = 1.0
        if self.backlog_mode == "bounded":
            time = section(cfg, "time")
            self.backlog_reference = (
                float(section(cfg, "sensors")["arrival_rate_per_sec"])
                * float(time["low_step_sec"]) * int(time["low_steps_per_frame"])
                * float(reward["upper_backlog_reference_frames"])
            )
            if not np.isfinite(self.backlog_reference) or self.backlog_reference <= 0:
                raise ValueError("bounded backlog requires a positive finite reference arrival volume")
        if not np.isfinite(self.episode_failure_weight) or self.episode_failure_weight < 0:
            raise ValueError("upper_episode_failure_weight must be finite and nonnegative")

    def __call__(
        self, serving_count: int, frame_max_mean: float, dead_count: float,
        *, episode_failed: bool = False, charging_count: int = 0, waiting_count: int = 0,
        lower_return_failure_count: int = 0,
        lower_reward_terms: list[Mapping[str, float]] | None = None,
    ) -> tuple[float, dict[str, float]]:
        backlog_cost = frame_max_mean / self.backlog_scale
        if self.backlog_mode == "bounded":
            backlog_cost = frame_max_mean / (frame_max_mean + self.backlog_reference)
        penalty = self.backlog_weight * backlog_cost
        if self.backlog_cap is not None:
            penalty = min(penalty, self.backlog_cap)
        terms = {
            "serving": self.serving_weight * serving_count,
            "frame_mean_system_max_post": -penalty,
            "charging": -self.charging_weight * charging_count,
            "waiting": -self.waiting_weight * waiting_count,
            "dead": -self.dead_weight * dead_count,
            "lower_return_failure": -self.lower_return_failure_weight * lower_return_failure_count,
            # Retained for legacy checkpoints; new runs set this weight to zero.
            "episode_failure": -self.episode_failure_weight if episode_failed and dead_count == 0 else 0.0,
        }
        if self.mode == "lower_data_mean":
            if not lower_reward_terms:
                raise ValueError("lower_data_mean requires executed lower-step reward terms")
            # Average the already weighted data terms, never lower failure/OOB costs.
            # This is mean(Bmax**2), not mean(Bmax)**2. Partial frames use actual K.
            collection = []
            for step_terms in lower_reward_terms:
                keys = [key for key in ("covered_pnorm", "collected_packets", "covered_max_sum")
                        if key in step_terms]
                if len(keys) != 1:
                    raise ValueError("each lower step must have exactly one collection term")
                collection.append(step_terms[keys[0]])
            terms.pop("serving")
            terms.pop("frame_mean_system_max_post")
            terms["frame_mean_lower_collection"] = float(np.mean(collection))
            terms["frame_mean_lower_backlog"] = float(np.mean([
                step_terms["system_max_post_service"] for step_terms in lower_reward_terms
            ]))
        if self.mode == "paper1_serving_backlog":
            terms["frame_mean_system_max_pre"] = terms.pop("frame_mean_system_max_post")
        terms = {key: value / self.divisor for key, value in terms.items()}
        return float(sum(terms.values())), terms


class UpperEnv:
    """One upper step owns planning, ten lower steps, settlement, and release."""

    def __init__(
        self,
        cfg: Mapping[str, Any],
        scene: Scene,
        scheduler: ChargingScheduler,
        energy_model: EnergyModel,
        low_runner: LowFrameRunner,
        metrics: EpisodeMetrics,
    ) -> None:
        self.cfg = cfg
        self.scene = scene
        self.scheduler = scheduler
        self.energy_model = energy_model
        self.low_runner = low_runner
        self.metrics = metrics
        self.upper_reward = UpperReward(cfg)
        self.failure_assessor = None
        settings = cfg.get("failure_responsibility", {})
        if settings and settings.get("mode", "legacy") != "legacy":
            from .failure_responsibility import FailureResponsibility
            if self.upper_reward.mode != "paper1_serving_backlog":
                raise ValueError("reference failure responsibility requires paper1_serving_backlog")
            if self.upper_reward.lower_return_failure_weight or self.upper_reward.episode_failure_weight:
                raise ValueError("disable legacy upper failure costs before enabling responsibility allocation")
            self.failure_assessor = FailureResponsibility(cfg, energy_model)
        self.low_runner.failure_assessor = self.failure_assessor
        self.max_frames = int(section(cfg, "time")["episode_upper_frames"])
        self.frame_sec = scene.low_step_sec * scene.low_steps_per_frame

    @property
    def trace(self) -> EpisodeTrace:
        return self.metrics.trace

    def reset(self, *, reset_rng: bool = True) -> tuple[dict[str, np.ndarray], dict[str, Any]]:
        self.scene.reset(reset_rng=reset_rng)
        self.metrics.reset(self.scene.sensor_backlog)
        return self.scene.observe_upper(), {"trace": self.trace}

    def step(
        self, upper_action: np.ndarray
    ) -> tuple[dict[str, np.ndarray], float, bool, bool, dict[str, Any]]:
        plan = self.scheduler.make_plan(self.scene, upper_action)
        self.scene.begin_upper_frame(plan)
        deferred = []
        callback = self.low_runner.on_step
        if self.failure_assessor is not None:
            def defer_final(obs, action, result):
                failed = result.dead_during_step.size or result.return_unsafe_ids.size
                last = result.step_in_frame == self.scene.low_steps_per_frame - 1
                if failed or last:
                    deferred.append((obs, action, result))
                elif callback is not None:
                    callback(obs, action, result)
            self.low_runner.on_step = defer_final
        try:
            low_frame = self.low_runner.run_frame(plan)
        finally:
            self.low_runner.on_step = callback

        settlement: dict[str, np.ndarray] = {}
        if low_frame.completed_all_steps:
            settlement = self.scene.complete_upper_frame(plan, self.energy_model)

        dead_ids = self.scene.dead_ids()
        failure_records = list(low_frame.failure_records)
        if self.failure_assessor is not None:
            for uid in settlement.get("failed_return_ids", []):
                record = self.failure_assessor.assess(uid, "return_failed_during_settlement", self.scene)
                failure_records.append(record)
                low_frame.steps[-1].failure_records.append(record)
            from .failure_responsibility import validate_failure_records
            previous_dead = np.flatnonzero(plan.frame_start_status == int(UAVStatus.DEAD))
            newly_dead = np.setdiff1d(dead_ids, previous_dead)
            validate_failure_records(failure_records, newly_dead)
            low_frame.failure_records = failure_records
        serving_count = int(np.sum(plan.assigned_status == int(UAVStatus.SERVING)))
        # Final-return failures carry a separate shared-responsibility cost;
        # exclude them from the ordinary upper death count to avoid double charging.
        lower_failure_ids = {
            int(uav_id)
            for step in low_frame.steps
            for uav_id in step.return_unsafe_ids
        }
        upper_dead_count = sum(int(uav_id) not in lower_failure_ids for uav_id in dead_ids)
        charging_count = int(np.sum(plan.assigned_status == int(UAVStatus.CHARGING)))
        waiting_count = int(np.sum(plan.assigned_status == int(UAVStatus.WAITING)))
        if self.upper_reward.mode == "paper1_serving_backlog":
            # Use this frame's roles, excluding deaths. Settlement can already
            # release or promote UAVs for the next frame.
            survived = self.scene.uav_status != int(UAVStatus.DEAD)
            counts = [int(np.sum(survived & (plan.assigned_status == int(status))))
                      for status in (UAVStatus.SERVING, UAVStatus.CHARGING, UAVStatus.WAITING)]
            pre_service_maxima = [step.system_max_pre_service for step in low_frame.steps]
            frame_max_pre = float(np.mean(pre_service_maxima)) if pre_service_maxima else 2400.0
            reward, reward_terms = self.upper_reward(
                counts[0], frame_max_pre,
                (sum(r["upper_weight"] for r in failure_records)
                 if self.failure_assessor is not None else int(dead_ids.size)),
                charging_count=counts[1], waiting_count=counts[2],
            )
        else:
            reward, reward_terms = self.upper_reward(
                serving_count, low_frame.mean_system_max_post_service, upper_dead_count,
                episode_failed=bool(low_frame.terminated or dead_ids.size),
                charging_count=charging_count, waiting_count=waiting_count,
                lower_return_failure_count=len(lower_failure_ids),
                lower_reward_terms=[step.reward_terms for step in low_frame.steps],
            )
        self.trace.frames.append(self._make_frame_record(plan, low_frame))

        terminated = bool(low_frame.terminated or dead_ids.size)
        truncated = bool(self.scene.upper_step >= self.max_frames and not terminated)
        observation = self.scene.observe_upper()
        info = {
            "frame_plan": plan,
            "low_frame": low_frame,
            "settlement": settlement,
            "reward_terms": reward_terms,
            "serving_count_during_frame": serving_count,
            "dead_ids_end": dead_ids.copy(),
            "trace": self.trace,
            "failure_records": failure_records,
        }
        if self.failure_assessor is not None:
            # A terminal episode has one tail cost, shared across its death events.
            info["failure_tail_lower_weight"] = (float(np.mean([r["lower_weight"] for r in failure_records]))
                                                 if failure_records else 0.)
            for obs, action, result in deferred:
                if callback is not None:
                    callback(obs, action, result)
        return observation, reward, terminated, truncated, info

    def render(self, **kwargs):
        """Draw the current scene and trace; see render_env for options."""
        from .render import render_env

        return render_env(self, **kwargs)

    def _make_frame_record(self, plan: FramePlan, low_frame: Any) -> FrameRecord:
        records: list[UAVFrameRecord] = []
        for uav_id in range(self.scene.num_uavs):
            role = UAVStatus(int(plan.assigned_status[uav_id])).name
            trajectory = [plan.frame_start_pos[uav_id].astype(float).tolist()]
            if role == "SERVING":
                trajectory.extend(
                    step.position_after[uav_id].astype(float).tolist()
                    for step in low_frame.steps
                )
            elif (
                low_frame.completed_all_steps
                and not plan.return_failure_mask[uav_id]
                and role in {"WAITING", "CHARGING"}
            ):
                end = self.scene.airship_pos.astype(float).tolist()
                if trajectory[-1] != end:
                    trajectory.append(end)

            collected = float(sum(s.collected_by_uav[uav_id] for s in low_frame.steps))
            owned_max = [s.per_uav_owned_max_pre_service[uav_id] for s in low_frame.steps]
            records.append(
                UAVFrameRecord(
                    uav_id=uav_id,
                    role_during_frame=role,
                    status_at_frame_end=UAVStatus(int(self.scene.uav_status[uav_id])).name,
                    trajectory_xy_m=trajectory,
                    battery_start_frac=float(plan.frame_start_battery[uav_id]),
                    battery_end_frac=float(self.scene.uav_battery[uav_id]),
                    return_time_sec=float(plan.return_time_sec[uav_id]),
                    return_energy_frac=float(plan.return_energy_frac[uav_id]),
                    charging_time_sec=float(plan.charging_time_sec[uav_id]),
                    waiting_time_sec=float(plan.waiting_time_sec[uav_id]),
                    collected_packets=collected,
                    mean_owned_max_pre_service=float(np.mean(owned_max)) if owned_max else 0.0,
                )
            )
        max_values = [s.system_max_post_service for s in low_frame.steps]
        mean_values = [s.system_mean_post_service for s in low_frame.steps]
        return FrameRecord(
            frame_index=len(self.trace.frames),
            duration_sec=len(low_frame.steps) * self.scene.low_step_sec,
            serving_count=int(np.sum(plan.assigned_status == int(UAVStatus.SERVING))),
            dead_ids_end=self.scene.dead_ids().tolist(),
            system_max_post_service_mean=float(np.mean(max_values)) if max_values else 0.0,
            system_mean_post_service_mean=float(np.mean(mean_values)) if mean_values else 0.0,
            uavs=records,
            settled=low_frame.completed_all_steps,
            termination_reason=low_frame.termination_reason or (
                "return_failed_during_settlement"
                if np.any(plan.return_failure_mask) and low_frame.completed_all_steps
                else None
            ),
        )
